          <?php  
include('head.php'); 
include('header.php'); 
?>

          <!--Page Title-->
          <section class="page-title" style="background-image:url(images/background/9.jpg)">
              <div class="auto-container">
                  <h1>Gallery</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>Gallery</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->


          <!--Team Section-->
          <section class="team-section">
              <div class="auto-container">
                  <!--Sec Title-->

                  <div class="four-item-carousel owl-carousel owl-theme">

                      <!--Team Block-->
                      <div class="team-block">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/resource/team-1.jpg" alt="" />

                              </div>

                          </div>
                      </div>


                      <!--Team Block-->
                      <div class="team-block">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/resource/team-2.jpg" alt="" />

                              </div>

                          </div>
                      </div>

                      <!--Team Block-->
                      <div class="team-block">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/resource/team-3.jpg" alt="" />

                              </div>

                          </div>
                      </div>

                      <!--Team Block-->
                      <div class="team-block">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/resource/team-4.jpg" alt="" />

                              </div>

                          </div>
                      </div>

                      <!--Team Block-->
                      <div class="team-block">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/resource/team-1.jpg" alt="" />

                              </div>

                          </div>
                      </div>


                      <!--Team Block-->
                      <div class="team-block">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/resource/team-2.jpg" alt="" />

                              </div>

                          </div>
                      </div>

                      <!--Team Block-->
                      <div class="team-block">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/resource/team-3.jpg" alt="" />

                              </div>

                          </div>
                      </div>

                      <!--Team Block-->
                      <div class="team-block">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/resource/team-4.jpg" alt="" />

                              </div>

                          </div>
                      </div>

                  </div>
              </div>
          </section>
          <!--End Team Section-->

          <?php include('footer.php'); ?>
