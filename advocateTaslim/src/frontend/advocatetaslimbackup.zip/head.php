<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Court marriage advocate in delhi/Ghaziabad, Court marriage lawyer in delhi/Ghaziabad, Lawyer for court marriage in new delhi/Ghaziabad, Lawyer for court marriage in delhi/Ghaziabad, Lawyer for same day court marriage in delhi/Ghaziabad, best lawyer for court marriage in delhi/Ghaziabad, Lawyer for foreigners court marriage in delhi/Ghaziabad, Court marriage lawyer for aryasamaj marriages, Court marriage lawyer for muslim marriages, Court marriage lawyer in delhi/Ghaziabad for intercaste marriages, Court marriage lawyer in delhi for interreligion marriages, Court Marriage lawyers in Ghaziabad,
        Tatkal court marriage Lawyers. In delhi/Ghaziabad, Online Marriage Booking, Marriage certificate in delhi/Ghaziabad
    </title>
    <meta name="description" content="Court marriage advocate in delhi/Ghaziabad, Court marriage lawyer in delhi/Ghaziabad, Lawyer for court marriage in new delhi/Ghaziabad, Lawyer for court marriage in delhi/Ghaziabad, Lawyer for same day court marriage in delhi/Ghaziabad, best lawyer for court marriage in delhi/Ghaziabad, Lawyer for foreigners court marriage in delhi/Ghaziabad, Court marriage lawyer for aryasamaj marriages, Court marriage lawyer for muslim marriages, Court marriage lawyer in delhi/Ghaziabad for intercaste marriages, Court marriage lawyer in delhi for interreligion marriages, Court Marriage lawyers in Ghaziabad,
        Tatkal court marriage Lawyers. In delhi/Ghaziabad, Online Marriage Booking, Marriage certificate in delhi/Ghaziabad">
    <meta name="keywords" content="Court marriage advocate in delhi/Ghaziabad, Court marriage lawyer in delhi/Ghaziabad, Lawyer for court marriage in new delhi/Ghaziabad, Lawyer for court marriage in delhi/Ghaziabad, Lawyer for same day court marriage in delhi/Ghaziabad, best lawyer for court marriage in delhi/Ghaziabad, Lawyer for foreigners court marriage in delhi/Ghaziabad, Court marriage lawyer for aryasamaj marriages, Court marriage lawyer for muslim marriages, Court marriage lawyer in delhi/Ghaziabad for intercaste marriages, Court marriage lawyer in delhi for interreligion marriages, Court Marriage lawyers in Ghaziabad,
        Tatkal court marriage Lawyers. In delhi/Ghaziabad, Online Marriage Booking, Marriage certificate in delhi/Ghaziabad">
    <meta name="author" content="Taslim Ahmad">
    <meta name="Designer" CONTENT="">
    <meta name="revisit-after" content="1 Days">
    <meta http-equiv="pragma" content="no-cache">
    <meta name="language" content="English">
    <meta name="rating" content="general">
    <meta name="GOOGLEBOT" content="INDEX,FOLLOW" />
    <meta name="ROBOTS" content="all" />
    <meta name="contenttype" content="Custom">
    <meta name="pagetype" content="Home">
    <meta name="approved" content="Yes">
    <meta name="ontoc" content="on">
    <meta name="editable" content="yes">
    <meta name="docgroup" content="Public">
    <meta name="searchable" content="yes">
    <meta name="owner" content="Taslim Ahmad">
    <!-- Stylesheets -->
    <link href="css/bootstrap.css" rel="stylesheet">


    <link href="plugins/revolution/css/settings.css" rel="stylesheet" type="text/css"><!-- REVOLUTION SETTINGS STYLES -->
    <link href="plugins/revolution/css/layers.css" rel="stylesheet" type="text/css"><!-- REVOLUTION LAYERS STYLES -->
    <link href="plugins/revolution/css/navigation.css" rel="stylesheet" type="text/css"><!-- REVOLUTION NAVIGATION STYLES -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">

    <!--Color Switcher Mockup-->
    <link href="css/color-switcher-design.css" rel="stylesheet">

    <!--Color Themes-->
    <link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">

    <link rel="shortcut icon" href="images/favicon.html" type="image/x-icon">
    <link rel="icon" href="images/favicon.html" type="image/x-icon">

    <!-- Responsive -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
    <style>
        /* Add styles to the form container */
        .container1 {
            position: absolute;
            right: 0;

            background-color: white;
            float: right;
            right: 0;
            margin: 100px;
            max-width: 300px;
            padding: 16px;
            background-color: white;
            width: 100%;
            top: -20px;


        }

        .container1 h4 {
            background-color: #223a8c;
            height: 60px;
            color: #FFFFFF;
            line-height: 60px;
            border-radius: 10px;
            font-weight: bold;

        }


        /* Full-width input fields */
        input[type=text],
        input[type=password] {
            width: 100%;
            padding: 10px;
            margin: 5px 0 5px 0;
            border: none;
            background: #f1f1f1;
        }

        input[type=text]:focus,
        input[type=password]:focus {
            background-color: #ddd;
            outline: none;
        }

        /* Set a style for the submit button */
        .btn {
            background-color: #333;
            color: white;

            border: none;
            cursor: pointer;
            width: 100%;
            opacity: 0.9;
        }

        .btn:hover {
            opacity: 1;
        }

    </style>
    <style>
        .blink-text {
            color: #000;
            font-weight: bold;
            font-size: 2rem;
            animation: blinkingText 2s infinite;
        }

        .blink-text a:hover,
        a:focus,
        a:visited {
            color: #FFFFFF;
        }

        @keyframes blinkingText {
            0% {
                color: #10c018;
            }

            25% {
                color: #1056c0;
            }

            50% {
                color: #ef0a1a;
            }

            75% {
                color: #254878;
            }

            100% {
                color: #04a1d5;
            }
        }

    </style>
    <style>
        .blink-bg {
            color: #fff;
            padding: 20px;
            display: inline-block;
            border-radius: 5px;
            animation: blinkingBackground 2s infinite;
        }

        @keyframes blinkingBackground {
            0% {
                background-color: #ffbf23;
            }

            25% {
                background-color: #00b4ff;
            }

            50% {
                background-color: #ef0a1a;
            }

            75% {
                background-color: #292929;
            }

            100% {
                background-color: #d5047a;
            }
        }

    </style>


    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-MD63TFBM');

    </script>
    <!-- End Google Tag Manager -->

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MD63TFBM" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    </head>
