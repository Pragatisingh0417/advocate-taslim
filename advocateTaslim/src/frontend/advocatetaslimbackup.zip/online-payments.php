          <?php  
include('head.php'); 
include('header.php'); 
?>

          <!--Page Title-->
          <section class="page-title" style="background-image:url(images/background/9.jpg)">
              <div class="auto-container">
                  <h1>Online Payments</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>Online Payments</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->

          <!--News Section-->
          <section class="news-section">
              <div class="auto-container">
                  <div class="sec-title">
                      <h2>Online <span class="theme_color">Payments</span></h2>
                  </div>
                  <div class="row clearfix">

                      <!--News Block-->
                      <div class="news-block-three col-md-4 col-sm-6 col-xs-12">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/p-3.jpg" alt="">
                              </div>

                          </div>
                      </div>

                      <!--News Block-->
                      <div class="news-block-three col-md-4 col-sm-6 col-xs-12">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/p-2.jpg" alt="">
                              </div>

                          </div>
                      </div>

                      <!--News Block-->
                      <div class="news-block-three col-md-4 col-sm-6 col-xs-12">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="images/p-1.jpg" alt="">
                              </div>

                          </div>
                      </div>

                  </div>
              </div>
          </section>
          <!--End News Section-->

          <?php include('footer.php'); ?>
