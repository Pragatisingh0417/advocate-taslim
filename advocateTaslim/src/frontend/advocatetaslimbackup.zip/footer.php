<!--Main Footer-->
<footer class="main-footer" style="background-image:url(images/background/5.jpg)">
    <div class="auto-container">
        <!--Widgets Section-->
        <div class="widgets-section">
            <div class="row clearfix">

                <!--Footer Column-->
                <div class="footer-column col-md-3 col-xs-12">
                    <div class="footer-widget logo-widget">
                        <div class="logo">
                            <a href="index.php"><img src="img/logo-white.png" alt="" /></a>
                        </div>
                        <div class="text">
                            <p align="justify">Advocate Taslim provides services for court marriage in Ghaziabad , Marriage Registrations, Solemnization of Marriages and assistance in issuing of Marriage Certificates. We have a rich experience in organizing court marriage in Ghaziabad in Delhi, Noida, Gurgaon, Ghaziabad, Meerut and other areas NCR ( national capital region).</p>
                        </div>
                    </div>
                </div>

                <!--Footer Column-->
                <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                    <div class="footer-widget links-widget">
                        <h2>Quick Links</h2>
                        <div class="row clearfix">

                            <div class="column col-md-4 col-sm-6 col-xs-12">
                                <ul class="list-style-one">
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about-us.php">About</a></li>
                                    <li><a href="request-a-call-back.php">Request A Call Back</a></li>
                                    <li><a href="online-payments.php">Online Payment</a></li>
                                    <li><a href="gallery.php">Gallery</a></li>
                                    <li><a href="contact.php">Contact Us</a></li>
                                </ul>
                            </div>

                            <div class="column col-md-8 col-sm-6 col-xs-12">

                                <ul class="list-style-one">

                                    <li><a href="Court-Marriage.php">Court Marriage</a></li>

                                    <li><a href="Legal-Notice.php">Legal Notice</a></li>
                                    <li><a href="Property-Registration.php">Property Registration</a></li>
                                    <li><a href="Marriage-Registration.php"> Marriage Registration</a></li>
                                    <li><a href="Divorce-Filing.php">Divorce Filing</a></li>

                                </ul>
                            </div>

                        </div>

                    </div>
                </div>

                <!--Footer Column-->
                <div class="footer-column col-md-3 col-xs-12">
                    <div class="footer-widget list-widget">
                        <h2>Contact info:</h2>
                        <ul class="list-style-two">
                            <li><span class="icon fa fa-envelope"></span>tsaifi6@gmail.com</li>
                            <li><span class="icon fa fa-phone"></span>+91 8826552527 |
                                +91 7678336800

                            </li>
                            <li><span class="icon fa fa-map-marker"></span>Tehsil, 133, New Gandhi Nagar,
                                Dayanand Nagar, Block A, Nehru
                                Nagar III, Sadar, Ghaziabad, Uttar Ghaziabad,
                                Uttar Pradesh 201001</li>


                        </ul>


                    </div>
                </div>

            </div>
        </div>

        <!--Footer Bottom-->
        <div class="footer-bottom">
            <div class="scroll-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

        </div>

    </div>
</footer>
<!--End Main Footer-->

<!-- Main Header-->
<header class="main-header">

    <!--Header Top-->
    <div class="header-top">
        <div class="auto-container">
            <div class="clearfix">
                <!--Top Left-->
                <div class="top-left pull-left">
                    <ul class="clearfix">
                        <li>Copyright © 2023 <span class="theme_color"> Advocate Taslim </span>All Right Reserved.| Designed by <span class="theme_color"><a href="https://gemwebservices.com/" target="_blank">Gem Web Services</a></span></li>
                    </ul>
                </div>
                <!--Top Right-->
                <div class="top-right pull-right">
                    <ul class="social-nav">
                        <li><a href="#" target="_blank"><span class="fa fa-facebook-f"></span></a></li>
                        <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="#" target="_blank"><span class="fa fa-youtube"></span></a></li>

                    </ul>
                    <!--Language-->

                </div>
            </div>
        </div>
    </div>

    </div>

    <!--End pagewrapper-->
    <a target="_blank" href="https://api.whatsapp.com/send?phone=+918826552527&amp;text=Hi,%20I%20contacted%20you%20Through%20your%20website." class="float" target="_blank">
        <i class="fa fa-whatsapp my-float"></i>
    </a>
    <a href="tel:+918826552527" class="float1">
        <i class="fa fa-phone my-float1"></i>
    </a>


    <script src="js/jquery.js"></script>
    <!--Revolution Slider-->
    <script src="plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
    <script src="plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
    <script src="plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
    <script src="plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <script src="plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
    <script src="plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
    <script src="plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
    <script src="js/main-slider-script.js"></script>

    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/jquery.fancybox.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/script.js"></script>

    <!--Color Switcher-->
    <script src="js/color-settings.js"></script>

    <script>
        function myFunction() {
            var dots = document.getElementById("dots");
            var moreText = document.getElementById("more");
            var btnText = document.getElementById("myBtn");

            if (dots.style.display === "none") {
                dots.style.display = "inline";
                btnText.innerHTML = "Read more";
                moreText.style.display = "none";
            } else {
                dots.style.display = "none";
                btnText.innerHTML = "Read less";
                moreText.style.display = "inline";
            }
        }

        let slideIndex = 0;
        showSlides();

        function showSlides() {
            let i;
            let slides = document.getElementsByClassName("mySlides");
            let dots = document.getElementsByClassName("dot");
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            slideIndex++;
            if (slideIndex > slides.length) {
                slideIndex = 1
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slides[slideIndex - 1].style.display = "block";
            dots[slideIndex - 1].className += " active";
            setTimeout(showSlides, 2000); // Change image every 2 seconds
        }

    </script>

    </body>



    </html>
