          <?php  
include('head.php'); 
include('header.php'); 
?>


          <!--Page Title-->
          <section class="page-title" style="background-image:url(images/background/9.jpg)">
              <div class="auto-container">
                  <h1>Thank You</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>Thank You</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->
          <!--History Section-->
          <section class="history-section" style="background-image:url(images/background/1.jpg)">
              <div class="auto-container">
                  <div class="row clearfix">

                      <!--Content Column-->
                      <div class="content-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">
                              <?php
                    if(isset($_POST['send_request'])){
                        //print_r($_POST); exit;
                        $headers = "From: developer@gemwebservices.com\r\n";
                        $headers .= "MIME-Version: 1.0" . "\r\n";
                        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

                        $name = $_POST['fullName'];
                        $mobile = $_POST['mobileNo'];
                        $email = $_POST['email'];
                        $message = $_POST['message'];
                        $subject = 'Contact Us';

                        $message = "Name: ".$name.'<br>Email: '.$email.'<br>Mobile No: '.$mobile.'<br>Message: '.$message;

                        $result = mail('nk442790@gmail.com', $subject, $message, $headers); 
                        if($result){ ?>
                              <div class="text-center">
                                  <h2 style="color:green;">Mail has been Sent Successfully.<br>We will Contact you as soon as possible.</h2>
                              </div>
                              <?php }
                        else{ ?>
                              <div class="text-center">
                                  <h2 style="color:red;">Mail Sending fail Please try Again</h2>
                              </div>
                              <?php } } ?>
                          </div>
                      </div>


                      <!--History Block-->


                      <!--History Block-->



                      <!--Video Column-->
                      <div class="video-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">

                              <!--Video Box-->
                              <div class="video-box">
                                  <figure class="image">
                                      <img src="img/call-back.jpg" alt="">
                                  </figure>

                              </div>
                          </div>

                      </div>

                  </div>
              </div>
          </section>
          <!--End History Section-->
          <?php include('footer.php'); ?>
