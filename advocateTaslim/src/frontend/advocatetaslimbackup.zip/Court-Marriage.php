          <?php  
include('head.php'); 
include('header.php'); 
?>


          <!--Page Title-->
          <section class="page-title" style="background-image:url(img/breadcrumb.jpg)">
              <div class="auto-container">

                  <h1>Court Marriage</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>Court Marriage</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->


          <!--History Section-->
          <section class="history-section" style="background-image:url(images/background/1.jpg)">
              <div class="auto-container">
                  <div class="row clearfix">


                      <!--Video Column-->
                      <div class="video-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">

                              <!--Video Box-->
                              <div class="video-box">
                                  <figure class="image">
                                      <img src="img/court.jpg" alt="">
                                  </figure>

                              </div>
                          </div>

                      </div>
                      <div class="content-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">


                              <!--History Block-->
                              <div class="history-block">
                                  <div class="inner-block">
                                      <div class="text" align="justify">Court marriage is a legal process to complete the wedding of two partners. It is performed in court according to the different laws in India. It allows the marriage of partners irrespective of their religion or caste. Under Article 21 of the Indian Constitution, everyone has the right to marry the person of their choice. There are many laws for court marriage & marriage registration in India. These laws can be the Special Marriage Act, Hindu Marriage Act, Anand Marriage Act, Indian Christian Marriage & Divorce Act, etc.<br><br> Court marriage is completely different from traditional marriage. During traditional marriages, all rituals & ceremonies are performed. But, all court marriages are performed in court in the presence of a marriage registrar & witnesses.</div>

                                  </div>
                              </div>

                              <!--History Block-->


                              <!--History Block-->


                          </div>
                      </div>


                  </div>
                  <div class="advisor-box">
                      <div class="blink-bg"><a href="request-a-call-back.html">Request Call Back</a></div>
                      <div class="blink-bg"><a href="tel:+91 8826552527">Call Us : +91 8826552527</a></div>

                  </div>
              </div>
          </section>
          <!--End History Section-->


          <?php include('footer.php'); ?>
