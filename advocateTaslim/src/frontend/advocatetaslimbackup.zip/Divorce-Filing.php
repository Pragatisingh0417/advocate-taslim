          <?php  
include('head.php'); 
include('header.php'); 
?>


          <!--Page Title-->
          <section class="page-title" style="background-image:url(img/breadcrumb.jpg)">
              <div class="auto-container">

                  <h1>Divorce Filing</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>Divorce Filing</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->


          <!--History Section-->
          <section class="history-section" style="background-image:url(images/background/1.jpg)">
              <div class="auto-container">
                  <div class="row clearfix">

                      <!--Content Column-->
                      <div class="content-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">


                              <!--History Block-->
                              <div class="history-block">
                                  <div class="inner-block">
                                      <div class="text" align="justify">The spouse can send a legal notice for divorce to the other spouse communicating his/her intention to undertake legal proceedings against the other party. Since legal notice is a formal communication sent by one person to the other, warning them would a good decision before taking any legal action.<br><br>
                                          Divorce procedure is governed by various laws/Acts prevalent in India. Divorce in India can be initiated by any of the party as per the grounds provided under the relevant laws prevalent in India. Generally among Hindus, Buddhists, Sikhs and Jains, Divorce is governed by the Hindu Marriage Act, 1955, for Muslims by the Dissolution of Muslim Marriages Act, 1939, for Parsis by the Parsi Marriage and Divorce Act, 1936 and for Christians it is governed by the Indian Divorce Act, 1869.
                                      </div>

                                  </div>
                              </div>

                              <!--History Block-->


                              <!--History Block-->


                          </div>
                      </div>

                      <!--Video Column-->
                      <div class="video-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">

                              <!--Video Box-->
                              <div class="video-box">
                                  <figure class="image">
                                      <img src="img/divorce.webp" alt="">
                                  </figure>

                              </div>
                          </div>

                      </div>


                  </div>
                  <div class="advisor-box">
                      <div class="blink-bg"><a href="request-a-call-back.html">Request Call Back</a></div>
                      <div class="blink-bg"><a href="tel:+91 8826552527">Call Us : +91 8826552527</a></div>

                  </div>
              </div>
          </section>
          <!--End History Section-->


          <?php include('footer.php'); ?>
