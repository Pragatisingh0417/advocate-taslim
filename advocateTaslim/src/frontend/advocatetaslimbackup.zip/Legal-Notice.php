          <?php  
include('head.php'); 
include('header.php'); 
?>


          <!--Page Title-->
          <section class="page-title" style="background-image:url(img/breadcrumb.jpg)">
              <div class="auto-container">

                  <h1>About Us</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>About Us</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->


          <!--History Section-->
          <section class="history-section" style="background-image:url(images/background/1.jpg)">
              <div class="auto-container">
                  <div class="row clearfix">

                      <!--Content Column-->
                      <div class="content-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">


                              <!--History Block-->
                              <div class="history-block">
                                  <div class="inner-block">
                                      <div class="text" align="justify">A legal notice is an intimation in unambiguous language that one person or entity sends to another person or entity. It helps in making recipients aware of the grievances of the sender. The legal notice is a written document that is drafted on legal terms and conditions for which parties get legally bound to acknowledge it. The sender who issues the legal notice has to inform the recipient about the notice issuance and is a warning given to a person before filing a legal suit against him. A well-vetted legal notice helps a recipient to avail the quickest remedy. It makes the recipient agree to the terms of the party who is sending the notice and thus eliminates the need to take the matter to court most of the time.<br><br>
                                          <h3>WHAT IS LEGAL NOTICE</h3>
                                          It is a way of formal written communication between Parties. Through this notice Sender signifies his intention of pursuing legal proceedings against the Recipient. This way the grievance of the Sender is also communicated to the Recipient.

                                      </div>
                                  </div>
                              </div>

                              <!--History Block-->


                              <!--History Block-->


                          </div>
                      </div>

                      <!--Video Column-->
                      <div class="video-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">

                              <!--Video Box-->
                              <div class="video-box">
                                  <figure class="image">
                                      <img src="img/legal.jpg" alt="">
                                  </figure>

                              </div>
                          </div>

                      </div>


                  </div>
                  <div class="advisor-box">
                      <div class="blink-bg"><a href="request-a-call-back.html">Request Call Back</a></div>
                      <div class="blink-bg"><a href="tel:+91 8826552527">Call Us : +91 8826552527</a></div>

                  </div>
              </div>
          </section>
          <!--End History Section-->


          <?php include('footer.php'); ?>
