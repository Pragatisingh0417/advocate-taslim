          <?php  
include('head.php'); 
include('header.php'); 
?>


          <!--Page Title-->
          <section class="page-title" style="background-image:url(img/breadcrumb.jpg)">
              <div class="auto-container">

                  <h1>Property Registration</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>Property Registration</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->

          <style>
              .inner-block li {
                  list-style: number;
              }

          </style>
          <!--History Section-->
          <section class="history-section" style="background-image:url(images/background/1.jpg)">
              <div class="auto-container">
                  <div class="row clearfix">

                      <!--Content Column-->
                      <div class="content-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">


                              <!--History Block-->
                              <div class="history-block">
                                  <div class="inner-block">
                                      <div class="text" align="justify"><b>WHAT IS PROPERTY REGISTRATION?</b><br>

                                          In India, property registration is mandatory to register all property transactions as per the provisions of the Registration Act, 1908. The transfer of immovable assets has to be recorded to obtain the rights of the property on the execution date of the deed.
                                          <br><br>
                                          <b>WHAT ALL PROPERTY DOCUMENTS DO I NEED TO REGISTER ? (THIS IS A TENTATIVE LIST)</b><br>
                                          <ul>
                                              <li>Estimation of the property value.</li>
                                              <li>Sale deed</li>
                                              <li>Payment of the stamp duty &amp;&nbsp;<strong>registration</strong>&nbsp;charges.</li>
                                              <li>Approach the Sub-Registrar for&nbsp;<strong>registration</strong>.</li>
                                              <li>Documents submission.</li>
                                              <li>Other documents as per the local requirements.&nbsp;</li>
                                          </ul>
                                          <br><br>
                                          <b>WHAT ALL PROPERTY DOCUMENTS DO I NEED TO REGISTER ? (THIS IS A TENTATIVE LIST)</b><br>
                                          <ul>
                                              <li>The property documents that need to be registered, should be submitted to the office of the Sub-Registrar of Assurances within whose jurisdiction the property, which is the subject matter of transfer, is situated.</li>
                                              <li>The authorised signatories for the seller and the purchaser, have to be present along with two witnesses, for registration of the documents. (The signatories should carry their proof of identity.) The documents that are accepted for this purpose, include Aadhaar Card, PAN Card, or any other proof of identity issued by a government authority.</li>
                                              <li>The signatories also have to furnish the power of attorney, if they are representing someone else. </li>
                                              <li>In case a company is party to the agreement, the person representing the company has to carry adequate documents, like power of attorney/letter of authority, along with a copy of the resolution of the company’s board, authorising him to carry out the registration.</li>
                                              <li>You need to present the property card to the sub-registrar, along with the original documents and proof of payment of stamp duty. Before registering the documents, the sub-registrar will verify whether adequate stamp duty has been paid for the property, as per the stamp duty ready reckoner. In case there is any deficit in the stamp duty, the registrar will refuse to register the documents.</li>
                                              <li>Stamp duty is the tax you pay to the government for attaining legal ownership over an asset, while the registration charge is the fee to get this legal formality completed in the government records. Stamp duty varies from state to state.</li>
                                              <li>In most states, women are offered rebates or waivers on stamp duty payment. Note here that witnesses are quite important in the overall process.</li>
                                              <li>The two witnesses that you intend to present during the registration, will also have to establish their identity in front of the sub-registrar. For this purpose, they should also carry their ID proofs and their address proofs. Additionally, their biometric identity will also be scanned during the process.</li>
                                          </ul>

                                      </div>

                                  </div>
                              </div>

                              <!--History Block-->


                              <!--History Block-->


                          </div>
                      </div>

                      <!--Video Column-->
                      <div class="video-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">

                              <!--Video Box-->
                              <div class="video-box">
                                  <figure class="image">
                                      <img src="img/property.jpg" alt="">
                                  </figure>

                              </div>
                          </div>

                      </div>


                  </div>
                  <div class="advisor-box">
                      <div class="blink-bg"><a href="request-a-call-back.html">Request Call Back</a></div>
                      <div class="blink-bg"><a href="tel:+91 8826552527">Call Us : +91 8826552527</a></div>

                  </div>
              </div>
          </section>
          <!--End History Section-->


          <?php include('footer.php'); ?>
