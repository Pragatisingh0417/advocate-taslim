          <?php  
include('head.php'); 
include('header.php'); 
?>


          <!--Page Title-->
          <section class="page-title" style="background-image:url(images/background/9.jpg)">
              <div class="auto-container">
                  <h1>Request a Call Back</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>Request a Call Back</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->
          <!--History Section-->
          <section class="history-section" style="background-image:url(images/background/1.jpg)">
              <div class="auto-container">
                  <div class="row clearfix">

                      <!--Content Column-->
                      <div class="content-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">
                              <form id="form1" name="form1" method="post" action="https://courtmarriagesindia.com/student_registration.php">
                                  <!--History Block-->
                                  <div class="history-block">
                                      <div class="inner-block">
                                          <div class="text" align="justify">


                                              <div class="appointment-two__form-bottom">
                                                  <div class="appointment-two__form-field">
                                                      <input name="fullName" type="text" size="38" placeholder="Enter Name" class="form-control form-control-name" />


                                                  </div><!-- /.appointment-two__form-field -->
                                                  <div class="appointment-two__form-field">
                                                      <input name="mobileNo" type="text" size="38" placeholder="Mobile Number" class="form-control form-control-email" />


                                                  </div><!-- /.appointment-two__form-field -->
                                                  <div class="appointment-two__form-field">
                                                      <input name="email" type="text" size="38" placeholder="Email ID" class="form-control form-control-company-name" />


                                                  </div><!-- /.appointment-two__form-field -->

                                                  <div class="appointment-two__form-field">
                                                      <textarea cols="28" name="correspondenceAddress" placeholder="Write your valuable feedback" class="form-control form-control-comments" /></textarea>



                                                  </div><!-- /.appointment-two__form-field -->
                                                  <!-- /.appointment-two__form-field -->
                                                  <div class="about-five">
                                                      <input type="submit" name="Submit" value="Submit" class="btn" />
                                                  </div>
                                                  <!-- /.appointment-two__form-field -->
                                              </div><!-- /.appointment-two__form-bottom -->
                              </form>
                          </div>
                      </div>
                  </div>

                  <!--History Block-->


                  <!--History Block-->


              </div>
              </div>

              <!--Video Column-->
              <div class="video-column col-md-6 col-sm-12 col-xs-12">
                  <div class="inner-column">

                      <!--Video Box-->
                      <div class="video-box">
                          <figure class="image">
                              <img src="img/call-back.jpg" alt="">
                          </figure>

                      </div>
                  </div>

              </div>

              </div>
              </div>
          </section>
          <!--End History Section-->
          <?php include('footer.php'); ?>
