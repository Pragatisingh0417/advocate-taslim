          <?php  
include('head.php'); 
include('header.php'); 
?>

          <!--Main Slider-->
          <section class="main-slider">

              <div class="rev_slider_wrapper fullwidthbanner-container" id="rev_slider_one_wrapper" data-source="gallery">
                  <div class="rev_slider fullwidthabanner" id="rev_slider_one" data-version="5.4.1">
                      <ul>

                          <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1687" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="img/1-1.jpg" data-title="Slide Title" data-transition="parallaxvertical">
                              <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="img/1-1.jpg">
                              <h1 class="banner-tit">Court Marriage & Registration</h1>
                          </li>

                          <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1688" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="img/1-2.jpg" data-title="Slide Title" data-transition="parallaxvertical">
                              <img alt="" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="img/1-2.jpg">
                              <h1 class="banner-tit">Court Marriage & Registration</h1>
                          </li>


                      </ul>
                  </div>

              </div><br>

              <form id="form1" name="form1" method="post" action="thankyou.php" class="container1">

                  <h4 align="center">Quick Enquiry</h4>


                  <input name="fullName" type="text" size="38" placeholder="Enter Name" />


                  <input name="mobileNo" type="text" size="38" placeholder="Mobile Number" />


                  <input name="email" type="text" size="38" placeholder="Email ID" />


                  <textarea cols="28" name="correspondenceAddress" placeholder="Your Message" style="    background: #f1f1f1;width:100%;padding:10px;" name="message"></textarea>



                  <input type="submit" name="send_request" value="Submit" class="btn" />

              </form>



          </section>
          <!--End Main Slider-->





          <!--About Section-->
          <section class="about-section">
              <div class="auto-container">
                  <div class="clearfix">

                      <!--Image Column-->
                      <div class="image-column col-md-6 col-sm-12 col-xs-12">
                          <div class="image">
                              <img src="img/about.jpg" alt="" />
                          </div>
                      </div>
                      <!--Content Column-->
                      <div class="content-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">
                              <h2>About <span class="theme_color">Advocate Taslim ...</span></h2>
                              <h3>Same day court marriages & registrations.</h3>

                              <div class="text">Advocate Taslim provides services for Court Marriages, Marriage Registrations, Solemnization of Marriages and assistance in issuing of Marriage Certificates. We have a rich experience in organizing court marriages in Delhi, Noida, Gurgaon, Ghaziabad, Meerut and other areas NCR ( national capital region). We have successfully provided our specialized services to numerous satisfied clients.</div>
                              <div class="clearfix">

                              </div>
                          </div>
                      </div>

                  </div>
              </div>
          </section>
          <!--End About Section-->

          <!--Fluid Section One-->
          <section class="fluid-section-one">
              <div class="outer-container clearfix">
                  <!--Image Column-->
                  <div class="image-column" style="background-image:url(img/whyus.jpg);">
                      <figure class="image-box"><img src="img/whyus.jpg" alt=""></figure>
                  </div>
                  <!--Content Column-->
                  <div class="content-column">
                      <div class="inner-column">
                          <div class="sec-title">
                              <h2>Why<span class="theme_color"> Choose Us?</span></h2>
                          </div>

                          <!--Feature Block-->
                          <div class="feature-block">
                              <div class="inner-block">
                                  <div class="icon-box">
                                      <img src="img/icon.png">
                                  </div>
                                  <h3>Swift Same-Day Service:
                                  </h3>
                                  <div class="text">We specialize in same-day court marriages and registration, eliminating the waiting period and streamlining the process.</div>
                              </div>
                          </div>

                          <!--Feature Block-->
                          <div class="feature-block">
                              <div class="inner-block">
                                  <div class="icon-box">
                                      <img src="img/icon.png">
                                  </div>
                                  <h3>Legal Experts On Hand:</h3>
                                  <div class="text">Our experienced legal team ensures that all marriages and registrations are fully compliant with local laws and regulations.</div>
                              </div>
                          </div>

                          <!--Feature Block-->
                          <div class="feature-block">
                              <div class="inner-block">
                                  <div class="icon-box">
                                      <img src="img/icon.png">
                                  </div>
                                  <h3>Transparent Pricing:</h3>
                                  <div class="text">Our pricing is transparent, with no hidden fees, so you know exactly what to expect from the start.</div>
                              </div>
                          </div>

                          <div class="feature-block">
                              <div class="inner-block">
                                  <div class="icon-box">
                                      <img src="img/icon.png">
                                  </div>
                                  <h3>Document Preparation Assistance:</h3>
                                  <div class="text">We assist you in preparing the necessary documents, reducing paperwork and minimizing stress.</div>
                              </div>
                          </div>

                          <div class="feature-block">
                              <div class="inner-block">
                                  <div class="icon-box">
                                      <img src="img/icon.png">
                                  </div>
                                  <h3>Friendly and Professional Staff:</h3>
                                  <div class="text">Our staff is known for their friendliness and professionalism, ensuring a comfortable and supportive experience.</div>
                              </div>
                          </div>

                          <div class="feature-block">
                              <div class="inner-block">
                                  <div class="icon-box">
                                      <img src="img/icon.png">
                                  </div>
                                  <h3>Your Privacy Matters:</h3>
                                  <div class="text">We take your privacy seriously, handling personal information and marriage details with the utmost confidentiality.</div>
                              </div>
                          </div>

                      </div>
                  </div>
              </div>
          </section>
          <!--End Fluid Section One-->

          <!--Team Section-->
          <section class="services-section-two style-two">
              <div class="auto-container">
                  <!--Sec Title-->
                  <div class="sec-title">
                      <h2>OUR<span class="theme_color"> SERVICES</span></h2>
                  </div>
                  <div class="three-item-carousel owl-carousel owl-theme">

                      <!--Team Block-->
                      <div class="services-block-two ">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="img/court.jpg" alt="" />

                              </div>
                              <div class="lower-box">
                                  <h3 align="center"><a href="court-marriage-and-marriage-registration.html">Court Marriage</a></h3>
                                  <div align="justify">Court Marriage is very different from the customary marriage and it happens in the presence of the Marriage Registrar. <br> <br></div>
                                  <div class="designation"></div>
                              </div>
                          </div>
                      </div>


                      <!--Team Block-->
                      <div class="services-block-two">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="img/legal.jpg" alt="" />

                              </div>
                              <div class="lower-box">
                                  <h3 align="center"><a href="procedure-and-documents-required-of-court-marriage.html">Legal Notice</a></h3>

                                  <div align="justify">It is a polite reminder by the sender to the receiver to resolve the issues of the sender. It is an opportunity for the receiver …<br><br>


                                  </div>

                              </div>
                          </div>
                      </div>

                      <!--Team Block-->
                      <div class="services-block-two">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="img/property.jpg" alt="" />

                              </div>
                              <div class="lower-box">
                                  <h3 align="center"><a href="foreigners-nri-marriages.html">Property Registration</a></h3>

                                  <div align="justify">Registration of property is a legal requirement to be followed when a person purchases certain defined land or property in India..<br>
                                      <br>
                                  </div>

                              </div>
                          </div>
                      </div>

                      <!--Team Block-->
                      <div class="services-block-two">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="img/marriage-registration.jpg" alt="" />

                              </div>
                              <div class="lower-box">
                                  <h3 align="center"><a href="aryasamaj-marriages.html"> Marriage Registration</a></h3>

                                  <div align="justify">Arya Samaj Marriages held, are very simple in affair and the Vedas are translated into Hindi/English, so that everybody can understand it.<br>
                                      <br>
                                  </div>

                              </div>
                          </div>
                      </div>

                      <!--Team Block-->
                      <div class="services-block-two">
                          <div class="inner-box">
                              <div class="image">
                                  <img src="img/divorce.webp" alt="" />

                              </div>
                              <div class="lower-box">
                                  <h3 align="center"><a href="muslim-marriage-nikah.html">Divorce Filing</a></h3>
                                  <div align="justify">Spouses who desire to choose mutual divorce are always perplexed about the procedure, role of court, terms & conditions. </a><br> <br></div>

                              </div>
                          </div>
                      </div>

                  </div>

          </section>

          <div class="clear"></div>

          <section class="testimonial">
              <div class="container">
                  <div class="row" style=" display:flex; align-items:center;">
                      <div class="col-lg-6 d-none d-lg-block">
                          <ol class="carousel-indicators tabs">
                              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active">
                                  <figure>
                                      <img src="img/amit.png" class="img-fluid" alt="">
                                  </figure>
                              </li>
                              <li data-target="#carouselExampleIndicators" data-slide-to="1">
                                  <figure>
                                      <img src="img/nadeem.png" class="img-fluid" alt="">
                                  </figure>
                              </li>
                              <li data-target="#carouselExampleIndicators" data-slide-to="2">
                                  <figure>
                                      <img src="img/taleeb.png" class="img-fluid" alt="">
                                  </figure>
                              </li>
                          </ol>
                      </div>
                      <div class="col-lg-6 d-flex justify-content-center align-items-center">
                          <div id="carouselExampleIndicators" data-interval="false" class="carousel slide" data-ride="carousel">
                              <h3>WHAT OUR CLIENTS SAY</h3>
                              <h1>TESTIMONIALS</h1>
                              <div class="slideshow-container">

                                  <div class="mySlides fade">
                                      <div class="text">smooth and hassle free service was provided. it took only 10 min at the counter and certificate was provided to me immediately after all procedures were completed. Best part is, all documentation were taken care by the team itself. i will surely recommend to reach out to him if you need marriage certificate urgently. Thanks you for all the support.</div><br>
                                      <span class="name"><b>Naresh Lal</b></span>
                                  </div>


                                  <div class="mySlides fade">
                                      <div class="text">Mr Taslim is very professional, & responsive. Trusted him to register my marriage. The entire process was seamless and completed fast. Everything was well documented & organized. I highly recommend his services. He is highly dependable person.</div>
                                      <br>
                                      <span class="name"><b>Lalit Saini</b></span>

                                  </div>

                                  <div class="mySlides fade">
                                      <div class="text">Taslim Ahmed is incredibly helpful and quick to respond. I enlisted his services to obtain a marriage certificate, and I must say, his service is truly outstanding. He efficiently organized all the necessary documents and ensured they met the necessary requirements. It took me hardly 15 min in all process. I can confidently attest to his professionalism and expertise in his field.</div>
                                      <br>
                                      <span class="name"><b>Shubham Verma</b></span>
                                  </div>


                                  <div class="mySlides fade">

                                      <div class="text">Mr Taslim service regarding marriage registration has been absolutely professional and fast. He made sure the documents were correctly filed with overall fast turnaround time. Thanks a lot for your help Taslim ji.</div>
                                      <br>
                                      <span class="name"><b>Keshav Jha</b></span>
                                  </div>

                                  <div class="mySlides fade">
                                      <div class="text">very nice experience. process was really smooth, all thanks to Mr Taslim Ahmed for assisting in us in best possible ways.. highly recommended</div>
                                      <br>
                                      <span class="name"><b>Mina </b></span>
                                  </div>

                              </div>
                              <div style="text-align:center">
                                  <span class="dot"></span>
                                  <span class="dot"></span>
                                  <span class="dot"></span>
                                  <span class="dot"></span>
                                  <span class="dot"></span>

                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>


          <?php include('footer.php'); ?>
