<body>

    <div class="page-wrapper">

        <!-- Preloader -->
        <div class="preloader"></div>

        <!-- Main Header-->
        <header class="main-header">

            <!--Header Top-->

            <!--Header-Upper-->
            <div class="header-upper">
                <div class="auto-container">
                    <div class="clearfix">

                        <div class="pull-left logo-box">
                            <div class="logo"><a href="https://advocatetaslim.com/"><img src="img/logo.png" width="150" alt="" title=""></a></div>
                        </div>
                        <!--Header Top-->
                        <div class="header-top">
                            <div class="auto-container">
                                <div class="clearfix">
                                    <!--Top Left-->

                                    <!--Top Right-->
                                    <div class="top-right pull-right">
                                        <ul class="social-nav">
                                            <li>
                                                <h4>Call or Whatsapp</h4>
                                                <a href="tel:+91 7678336800"><span><span>
                                                            <blink class="blink-text">+91 7678336800</blink>
                                                        </span></span>
                                                </a> |
                                                <a href="tel:+91 8826552527"><span>
                                                        <blink class="blink-text">+91 8826552527</blink>
                                                    </span> </a>
                                            </li>

                                            <li>
                                                <h4>Customer Support</h4>
                                                <strong><a href="tel:+91 8826552527">
                                                        <blink class="blink-text">24X7</blink>&nbsp;Click Here
                                                    </a></strong>
                                            </li>
                                            <li>
                                                <h4> Marriage Certificate <strong>in 2 hours</strong></h4>
                                                <strong>{ issued by govt of india}</strong>
                                            </li>

                                        </ul>
                                        <!--Language-->

                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--Info Box-->


                    </div>
                </div>
            </div>
            <!--End Header Upper-->

            <!--Header Lower-->
            <div class="header-lower">

                <div class="auto-container">
                    <div class="nav-outer clearfix">
                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <div class="navbar-header">
                                <!-- Toggle Button -->
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>

                            <div class="navbar-collapse collapse clearfix">
                                <ul class="navigation clearfix">
                                    <li><a href="https://advocatetaslim.com/">Home</a></li>
                                    <li><a href="about-us.php">About us</a>
                                    </li>
                                    <li><a href="request-a-call-back.php">Request A Call Back</a>

                                    </li>
                                    <li class="dropdown"><a href="#">Our Services</a>
                                        <ul>
                                            <li><a href="Court-Marriage.php">Court Marriage</a></li>

                                            <li><a href="Legal-Notice.php">Legal Notice</a></li>
                                            <li><a href="Property-Registration.php">Property Registration</a></li>
                                            <li><a href="Marriage-Registration.php"> Marriage Registration</a></li>
                                            <li><a href="Divorce-Filing.php">Divorce Filing</a></li>

                                        </ul>
                                    </li>

                                    <li><a href="online-payments.php">Online Payments</a>
                                    </li>
                                    <li><a href="gallery.php">Gallery</a>
                                    </li>
                                    <li><a href="contact.php">Contact us</a></li>
                                </ul>
                            </div>
                        </nav>
                        <!-- Main Menu End-->
                        <div class="outer-box clearfix">

                            <!--Search Box-->


                            <div class="advisor-box">
                                <div class="blink-bg"><a href="request-a-call-back.php">For Online Booking click here</a></div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!--End Header Lower-->

            <!--Sticky Header-->
            <div class="sticky-header">
                <div class="auto-container clearfix">
                    <!--Logo-->
                    <div class="logo pull-left">
                        <a href="index.php" class="img-responsive"><img src="img/logo.png" alt="" title="" width="100"></a>
                    </div>

                    <!--Right Col-->
                    <div class="right-col pull-right">
                        <!-- Main Menu -->
                        <nav class="main-menu">
                            <div class="navbar-header">
                                <!-- Toggle Button -->
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>

                            <div class="navbar-collapse collapse clearfix">
                                <ul class="navigation clearfix">
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about-us.php">About us</a>
                                    </li>
                                    <li><a href="request-a-call-back.php">Request A Call Back</a>

                                    </li>
                                    <li class="dropdown"><a href="#">Our Services</a>
                                        <ul>
                                            <li><a href="Court-Marriage.php">Court Marriage</a></li>

                                            <li><a href="Legal-Notice.php">Legal Notice</a></li>
                                            <li><a href="Property-Registration.php">Property Registration</a></li>
                                            <li><a href="Marriage-Registration.php"> Marriage Registration</a></li>
                                            <li><a href="Divorce-Filing.php">Divorce Filing</a></li>

                                        </ul>
                                    </li>

                                    <li><a href="online-payments.php">Online Payments</a>
                                    </li>
                                    <li><a href="gallery.php">Gallery</a>
                                    </li>
                                    <li><a href="contact.php">Contact us</a></li>
                                </ul>
                            </div>
                        </nav><!-- Main Menu End-->
                    </div>

                </div>
            </div>
            <!--End Sticky Header-->

        </header>
        <!--End Main Header -->
