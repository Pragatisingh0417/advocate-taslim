          <?php  
include('head.php'); 
include('header.php'); 
?>


          <!--Page Title-->
          <section class="page-title" style="background-image:url(img/breadcrumb.jpg)">
              <div class="auto-container">

                  <h1>About Us</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>About Us</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->
          <section class="fluid-section-one">
              <div class="outer-container clearfix">
                  <!--Image Column-->
                  <div class="image-column" style="background-image:url(img/contact.jpg);">
                      <figure class="image-box"><img src="images/contact.jpg" alt=""></figure>
                  </div>
                  <!--Content Column-->
                  <div class="content-column">
                      <div class="inner-column">

                          <!--Feature Block-->

                          <div class="feature-block">
                              <div class="inner-block">
                                  <div class="icon-box">
                                      <span class="icon flaticon-phone-call-1"></span>
                                  </div>
                                  <h3><a href="tel:+91 8826552527">+91 8826552527</a></h3><br>
                              </div>
                          </div>


                          <!--Feature Block-->
                          <div class="feature-block">
                              <div class="inner-block">
                                  <div class="icon-box">
                                      <span class="icon flaticon-envelope-1"></span>
                                  </div>
                                  <h3><a href="mailto:tsaifi6@gmail.com"> tsaifi6@gmail.com</a></h3><br>
                              </div>
                          </div>

                          <div class="feature-block">
                              <div class="inner-block">
                                  <div class="icon-box">
                                      <span class="icon flaticon-map-marker"></span>
                                  </div>
                                  <h3>Tehsil, 133, New Gandhi Nagar,<br>


                                      Dayanand Nagar, Block A, Nehru<br>


                                      Nagar III, Sadar, Ghaziabad, Uttar Ghaziabad, <br>Uttar Pradesh 201001</h3><br>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </section>

          <?php include('footer.php'); ?>
