          <?php  
include('head.php'); 
include('header.php'); 
?>


          <!--Page Title-->
          <section class="page-title" style="background-image:url(img/breadcrumb.jpg)">
              <div class="auto-container">

                  <h1>About Us</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>About Us</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->


          <!--History Section-->
          <section class="history-section" style="background-image:url(images/background/1.jpg)">
              <div class="auto-container">
                  <div class="row clearfix">

                      <!--Content Column-->
                      <div class="content-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">


                              <!--History Block-->
                              <div class="history-block">
                                  <div class="inner-block">
                                      <div class="text" align="justify">( Advocates, Solicitors & Legal Consultants )
                                          Advocate Taslim is a law firm in Ghaziabad Tehsil, founded in the year 2010 .<br> Since the beginning, the main theme of Advocate Taslim ,the founder of the said firm was to serve as a single-window legal service provider i.e. Advocates, solicitors and also as a Legal Consultant in this dynamic commercial environment.<br><br> The said law firm brought its services to the table with a team of committed and dedicated professional Advocates and Lawyers in Ghaziabad Tehsil, who are specialist in their respective fields of practice of Law in Ghaziabad and whole of NCR and pursued a philosophy of symbiotic relationships with litigants.</div><br><br>
                                      <div class="text" align="justify"><b>Basing its beliefs on the Vedas, Advocate Taslim beliefs are as follows</b></div>
                                      <div class="text" align="justify">
                                          <ul>

                                              <li>It believes in three external existences, god, soul and nature. These three existences are different from each other.</li>
                                              <li>God is formless and does not take birth in any form. Therefore, Advocate Taslim does not believe in idol worship and incarnation of god.</li>
                                              <li>It believes that the four Vedas are not depended on any verbal authority for authenticity as they are self evident. It also believes in Brahmanas relating to the four Vedas, six branches of the Vedas, eleven Upanishads to the extent they are in agreement with the Vedas.</li>
                                              <li>It believes that Dharma is that which is just, true, free from bias and not opposed to the laws of God. Adharma is that which is untrue, biased and opposed to God’s laws.</li>
                                          </ul>
                                      </div>
                                  </div>
                              </div>

                              <!--History Block-->


                              <!--History Block-->


                          </div>
                      </div>

                      <!--Video Column-->
                      <div class="video-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">

                              <!--Video Box-->
                              <div class="video-box">
                                  <figure class="image">
                                      <img src="img/about.jpg" alt="">
                                  </figure>

                              </div>
                          </div>

                      </div>


                  </div>
                  <div class="advisor-box">
                      <div class="blink-bg"><a href="request-a-call-back.html">Request Call Back</a></div>
                      <div class="blink-bg"><a href="tel:+91 8826552527">Call Us : +91 8826552527</a></div>

                  </div>
              </div>
          </section>
          <!--End History Section-->


          <?php include('footer.php'); ?>
