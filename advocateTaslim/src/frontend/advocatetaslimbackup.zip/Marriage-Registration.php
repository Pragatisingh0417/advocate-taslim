          <?php  
include('head.php'); 
include('header.php'); 
?>


          <!--Page Title-->
          <section class="page-title" style="background-image:url(img/breadcrumb.jpg)">
              <div class="auto-container">

                  <h1>Marriage Registration</h1>
                  <ul class="page-breadcrumb">
                      <li>You are here:</li>
                      <li><a href="index.php"> Home</a></li>
                      <li>Marriage Registration</li>
                  </ul>
              </div>
          </section>
          <!--End Page Title-->


          <!--History Section-->
          <section class="history-section" style="background-image:url(images/background/1.jpg)">
              <div class="auto-container">
                  <div class="row clearfix">

                      <!--Content Column-->
                      <div class="content-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">


                              <!--History Block-->
                              <div class="history-block">
                                  <div class="inner-block">
                                      <div class="text" align="justify">If you feel stuck in a marriage which is not legal or void in the eyes of law and want to get out of such marriage, you will need guidance from the good lawyers for making an application and declaring the marriage as null and void.<br><br>
                                          A Marriage (Arya Samaj Marriage or an arranged Marriage) is directly registered by the Registrar of Marriage under section 8 of Hindu Marriage Act-1955 on the same working day. Verification of all the documents is carried out on the date of application and thereafter Marriage is registered on the same working day by the registrar of marriage appointed by the Govt. of India and marriage certificate is issued.
                                          Any Confusion ? Just Request a Call Back or Call us.

                                      </div>
                                  </div>

                                  <!--History Block-->


                                  <!--History Block-->


                              </div>
                          </div>
                      </div>

                      <!--Video Column-->
                      <div class="video-column col-md-6 col-sm-12 col-xs-12">
                          <div class="inner-column">

                              <!--Video Box-->
                              <div class="video-box">
                                  <figure class="image">
                                      <img src="img/marriage-registration.jpg" alt="">
                                  </figure>

                              </div>
                          </div>

                      </div>


                  </div>
                  <div class="advisor-box">
                      <div class="blink-bg"><a href="request-a-call-back.html">Request Call Back</a></div>
                      <div class="blink-bg"><a href="tel:+91 8826552527">Call Us : +91 8826552527</a></div>

                  </div>
              </div>
          </section>
          <!--End History Section-->


          <?php include('footer.php'); ?>
